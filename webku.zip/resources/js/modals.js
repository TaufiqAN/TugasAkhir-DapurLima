// import Swal from 'sweetalert2';

// export function showLoginModal() {
//     Swal.fire({
//         title: 'Login Dulu Yuk!',
//         text: "Untuk menyimpan resep, kamu perlu login terlebih dahulu.",
//         icon: 'warning',
//         showCancelButton: true,
//         confirmButtonColor: '#10B981',
//         cancelButtonColor: '#d33',
//         confirmButtonText: 'Login',
//         cancelButtonText: 'Batal'
//     }).then((result) => {
//         if (result.isConfirmed) {
//             window.location.href = '/login';
//         }
//     })
// }

// window.showLoginModal = showLoginModal;