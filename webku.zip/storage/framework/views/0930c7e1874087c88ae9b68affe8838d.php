 

<?php $__env->startSection('content'); ?>

<div class="max-w-5xl mx-auto bg-white p-6 rounded-lg mt-36">
    <div class="grid md:grid-cols-2 gap-6">
        <div>
            <img src="<?php echo e(asset('storage/' . $resep->image)); ?>" alt="<?php echo e($resep->nama_resep); ?>" class="h-72 w-full object-cover rounded-lg shadow">
        </div>
    
        
        <div>
            <div class="flex justify-between items-start">
                <h1 class="text-4xl font-bold text-green-700"><?php echo e($resep->nama_resep); ?></h1>
                
                <?php if(auth()->guard()->check()): ?>
                    <?php
                        $isSaved = auth()->user()->saves->contains('resep_id', $resep->id);
                    ?>
                    <button class="save-btn" data-resep-id="<?php echo e($resep->id); ?>" 
                        <?php if(auth()->guard()->guest()): ?> onclick="showLoginModal()" <?php endif; ?>>
                        <?php if($isSaved): ?>
                        <svg class="w-10 h-10 text-yellow-500" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M7.833 2c-.507 0-.98.216-1.318.576A1.92 1.92 0 0 0 6 3.89V21a1 1 0 0 0 1.625.78L12 18.28l4.375 3.5A1 1 0 0 0 18 21V3.889c0-.481-.178-.954-.515-1.313A1.808 1.808 0 0 0 16.167 2H7.833Z"/>
                        </svg>
                        <?php else: ?>
                        <svg class="w-10 h-10 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M17 21l-5-4-5 4V3.889a.92.92 0 0 1 .244-.629.808.808 0 0 1 .59-.26h8.333a.81.81 0 0 1 .589.26.92.92 0 0 1 .244.63V21z" />
                        </svg>
                        <?php endif; ?>
                    </button>
                <?php endif; ?>
            </div>
    
            
            <div class="flex items-center gap-1 my-1">
                <span class="text-yellow-500 font-semibold text-xl">
                    ★ <?php echo e(number_format($resep->total_rating ?? 0, 1)); ?> 
                </span>
                <span class="text-sm text-gray-500"> (<?php echo e($resep->reviews->count()); ?> Ulasan)</span>
            </div>
    
            <p class="mt-2 text-gray-700"><?php echo e($resep->deskripsi); ?></p>
    
            
            <div class="mt-4 flex flex-wrap gap-2">
                <span class="bg-blue-500 text-white px-3 py-1 rounded-lg text-sm">Kategori: <?php echo e($resep->kategori->nama_kategori ?? 'Tidak ada'); ?></span>
                <span class="bg-yellow-500 text-white px-3 py-1 rounded-lg text-sm">Kesulitan: <?php echo e($resep->kesulitan); ?></span>
                <span class="bg-green-500 text-white px-3 py-1 rounded-lg text-sm">Waktu: <?php echo e($resep->waktu); ?> menit</span>
                <span class="bg-purple-500 text-white px-3 py-1 rounded-lg text-sm">Porsi: <?php echo e($resep->porsi); ?></span>
            </div>
        </div>
    </div>
    

     
    <div class="mt-8 grid md:grid-cols-2 gap-6">
         
        <div class="bg-blue-100 p-4 rounded-lg shadow">
            <h3 class="text-lg font-bold text-blue-700">Bahan</h3>
            <ul class="mt-2 list-none space-y-3">
                <?php $__currentLoopData = json_decode($resep->bahan); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $bahann): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flex items-center space-x-3 text-gray-800">
                        <span class="bg-blue-500 text-white w-6 h-6 flex items-center justify-center rounded-full"><?php echo e($index + 1); ?></span>
                        <span class="flex-1"><?php echo e($bahann); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

         
        <div class="bg-green-100 p-4 rounded-lg shadow">
            <h3 class="text-lg font-bold text-green-700">Cara Membuat</h3>
            <ul class="mt-2 list-none space-y-3">
                <?php $__currentLoopData = json_decode($resep->cara_membuat); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $cara_membuatt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flex items-start space-x-3 text-gray-800">
                        <span class="bg-green-500 text-white w-6 h-6 flex items-center justify-center rounded-full"><?php echo e($index + 1); ?></span>
                        <span class="flex-1"><?php echo e($cara_membuatt); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>



    
    <?php if(auth()->guard()->check()): ?>
    <div class="w-full mx-auto mt-5">
        <div class="p-6 bg-gray-100 text-center rounded-xl">
            <h2 class="text-xl font-bold text-gray-900">Jadilah yang pertama mengulas.</h2>
            <button id="openModal" class="mt-4 px-6 py-2 text-green-600 border border-green-600 rounded-full font-medium hover:bg-green-600 hover:text-white transition-all duration-300">Menulis review</button>
        </div>
    </div>
    
    
    <div id="reviewModal" class="z-50 fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center hidden px-4 overflow-y-auto">
        <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md my-10">
            <h2 class="text-2xl pb-2 font-semibold text-center">Rating dan Ulasan</h2>

            <div class="flex items-center gap-4 overflow-hidden rounded-lg mt-2">
                <img src="<?php echo e(asset('storage/' . $resep->image)); ?>" 
                    alt="<?php echo e($resep->nama_resep); ?>"
                    class="w-24 h-20 object-cover rounded-lg brightness-75 transition-all duration-300 group-hover:brightness-100 group-hover:scale-105">
                <span class="font-medium text-base text-gray-700"><?php echo e($resep->nama_resep); ?></span>
            </div>
            
            <form id="reviewForm" method="POST" action="<?php echo e(route('reviews.store')); ?>" class="mt-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="resep_id" value="<?php echo e($resep->id); ?>">

                
                <div class="mt-2"> 
                    <label class="block text-gray-600 text-base">Rating</label>
                    <div id="rating" class="flex space-x-1 cursor-pointer">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <span class="star text-gray-300 text-4xl sm:text-5xl md:text-6xl" data-value="<?php echo e($i); ?>">★</span>
                        <?php endfor; ?>
                    </div>
                    <input type="hidden" name="rating" id="ratingValue" value="0">
                </div>

                
                <div class="mt-4">
                    <label class="block text-gray-600 py-1 text-base">Ulasan</label>
                    <textarea name="ulasan" class="border rounded p-2 w-full" rows="4" placeholder="Tulis ulasanmu..." required></textarea>
                </div>

                
                <div class="mt-4 flex justify-end space-x-2">
                    <button type="button" id="closeModal" class="bg-gray-500 text-white px-4 py-2 rounded">Batal</button>
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Kirim</button>
                </div>
            </form>
        </div>
    </div>
    <?php else: ?>
    <div class="w-full mx-auto mt-5">
        <div class="p-6 bg-gray-100 text-center rounded-xl">
            <h2 class="text-xl font-bold text-gray-900">Jadilah yang pertama mengulas.</h2>
            <button onclick="showLoginModal()" 
                class="mt-4 inline-block px-6 py-2 text-green-600 border border-green-600 rounded-full font-medium hover:bg-green-600 hover:text-white transition-all duration-300">
                Menulis review
            </button>
        </div>
    </div>
    <?php endif; ?>
    
    
    <div id="reviews" class="p-4 bg-white border border-gray-200 rounded-xl mt-4">
        <div class="mb-6">
            <h2 class="text-2xl font-semibold text-gray-800">Ulasan 
                <span class="font-normal text-gray-400"><?php echo e($resep->reviews->count()); ?></span>
            </h2>
        </div>

        <?php if(session('success')): ?>
            <div class="mb-4 p-3 bg-green-100 text-green-700 rounded">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($resep->reviews->isEmpty()): ?>
            <div id="no-review"  class="flex flex-col items-center justify-center text-center text-gray-600 py-6">
                <svg class="w-16 h-16 mb-3 text-gray-300" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                    <path fill-rule="evenodd" d="M5 3a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11.5c.07 0 .14-.007.207-.021.095.014.193.021.293.021h2a2 2 0 0 0 2-2V7a1 1 0 0 0-1-1h-1a1 1 0 1 0 0 2v11h-2V5a2 2 0 0 0-2-2H5Zm7 4a1 1 0 0 1 1-1h.5a1 1 0 1 1 0 2H13a1 1 0 0 1-1-1Zm0 3a1 1 0 0 1 1-1h.5a1 1 0 1 1 0 2H13a1 1 0 0 1-1-1Zm-6 4a1 1 0 0 1 1-1h6a1 1 0 1 1 0 2H7a1 1 0 0 1-1-1Zm0 3a1 1 0 0 1 1-1h6a1 1 0 1 1 0 2H7a1 1 0 0 1-1-1ZM7 6a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1V7a1 1 0 0 0-1-1H7Zm1 3V8h1v1H8Z" clip-rule="evenodd"/>
                </svg>              
                <p class="text-lg font-semibold">Belum ada ulasan</p>
                <p class="text-sm text-gray-500">Jadilah yang pertama memberikan ulasan pada resep ini!</p>
            </div>
        <?php else: ?>
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul class="pt-4 mt-4 space-y-2 font-medium border-t dark:border-gray-600">

                
                <p class="font-semibold text-lg text-gray-800"><?php echo e($review->user->name); ?></p>
                <div class="flex items-center text-yellow-400">
                    <?php for($i = 1; $i <= 5; $i++): ?>
                        <?php if($i <= $review->rating): ?>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.974a1 1 0 00.95.69h4.178c.969 0 1.371 1.24.588 1.81l-3.38 2.455a1 1 0 00-.364 1.118l1.287 3.974c.3.921-.755 1.688-1.54 1.118l-3.38-2.455a1 1 0 00-1.175 0l-3.38 2.455c-.784.57-1.838-.197-1.539-1.118l1.287-3.974a1 1 0 00-.364-1.118L2.045 9.4c-.783-.57-.38-1.81.588-1.81h4.178a1 1 0 00.95-.69l1.287-3.974z" />
                            </svg>
                        <?php else: ?>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-300" viewBox="0 0 20 20" fill="currentColor">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.974a1 1 0 00.95.69h4.178c.969 0 1.371 1.24.588 1.81l-3.38 2.455a1 1 0 00-.364 1.118l1.287 3.974c.3.921-.755 1.688-1.54 1.118l-3.38-2.455a1 1 0 00-1.175 0l-3.38 2.455c-.784.57-1.838-.197-1.539-1.118l1.287-3.974a1 1 0 00-.364-1.118L2.045 9.4c-.783-.57-.38-1.81.588-1.81h4.178a1 1 0 00.95-.69l1.287-3.974z" />
                            </svg>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
                <p class="text-gray-700"><?php echo e($review->ulasan); ?></p>
                <p><span class="text-xs text-gray-500"><?php echo e($review->created_at->diffForHumans()); ?></span></p>

                
                <div class="review" data-review-id="<?php echo e($review->id); ?>">
                    <button onclick="toggleLike(this)" class="flex items-center space-x-2 transition">
                        <span class="like-icon">
                            <svg class="w-6 h-6 text-gray-800" xmlns="http://www.w3.org/2000/svg" fill="none"
                                viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M7 11c.889-.086 1.416-.543 2.156-1.057a22.323 22.323 0 0 0 3.958-5.084 1.6 1.6 0 0 1 .582-.628 1.549 1.549 0 0 1 1.466-.087c.205.095.388.233.537.406a1.64 1.64 0 0 1 .384 1.279l-1.388 4.114M7 11H4v6.5A1.5 1.5 0 0 0 5.5 19v0A1.5 1.5 0 0 0 7 17.5V11Zm6.5-1h4.915c.286 0 .372.014.626.15.254.135.472.332.637.572a1.874 1.874 0 0 1 .215 1.673l-2.098 6.4C17.538 19.52 17.368 20 16.12 20c-2.303 0-4.79-.943-6.67-1.475"/>
                            </svg>
                        </span>
                        <span class="like-count text-sm"><?php echo e($review->likes_count ?? 0); ?></span>
                    </button>
                </div>

                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->check() && (auth()->user()->role === 'admin' || auth()->id() === $review->user_id)): ?>
                        <form action="<?php echo e(route('admin.reviews.destroy', $review->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus ulasan ini?');" class="mt-2">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-sm text-red-500 hover:text-red-700">
                                Hapus Ulasan
                            </button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
                

                

                <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role === 'admin'): ?>
                    <button onclick="toggleReplyForm(<?php echo e($review->id); ?>)" class="mt-2 text-sm text-blue-600 hover:underline">Balas</button>

                    <div id="reply-form-<?php echo e($review->id); ?>" class="hidden mt-2">
                        <textarea id="reply-content-<?php echo e($review->id); ?>" class="w-full border border-gray-300 rounded-lg p-2 text-sm" placeholder="Tulis Balasan"></textarea>
                        <button onclick="submitReply(<?php echo e($review->id); ?>)" class="mt-2 inline-flex items-center px-3 py-1.5 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700">Kirim</button>
                        <span id="loading-<?php echo e($review->id); ?>" class="hidden text-sm text-gray-500 ml-2">Mengirim...</span>
                    </div>
                <?php endif; ?>
                <?php endif; ?>

                
                <div id="reply-container-<?php echo e($review->id); ?>" class="mt-2 space-y-2">
                <?php $__currentLoopData = $review->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-2 border-l-4 border-gray-700 pl-4 mt-2">
                        <p class="font-semibold text-lg text-gray-800"><?php echo e($reply->user->name); ?></p>
                        <p class="text-gray-700"><?php echo e($reply->content); ?></p>
                        <p><span class="text-xs text-gray-500"><?php echo e($reply->created_at->diffForHumans()); ?></span></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        
        <div class="mt-6">
            <?php echo e($reviews->links()); ?>

        </div>
        
    </div>
    


    
    <div class="max-w-6xl mx-auto py-10">
         
        <h2 class="text-3xl font-bold text-gray-800 text-center font-jakarta">Coba Resep Lainnya</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-6">

            <?php $__currentLoopData = $allResep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
             
            <div class="block group">
                <a href="<?php echo e(route('makanan.detail', $resep->id)); ?>" class="block">
                    <div class="relative overflow-hidden rounded-lg">
                        <img src="<?php echo e(asset('storage/' . $resep->image)); ?>" 
                            alt="<?php echo e($resep->nama_resep); ?>"
                            class="w-full h-52 object-cover rounded-lg brightness-75 transition-all duration-300 
                                group-hover:brightness-100 group-hover:scale-105">
                    </div>
                </a>

                <div class="mt-4 flex justify-between items-start">
                    <a href="<?php echo e(route('makanan.detail', $resep->id)); ?>" class="text-xl font-semibold text-gray-900 group-hover:text-green-700 transition-all duration-300 min-h-[50px]">
                        <?php echo e($resep->nama_resep); ?>

                    </a>
                     
                    <?php if(auth()->guard()->check()): ?>
                        <?php
                            $isSaved = auth()->user()->saves->contains('resep_id', $resep->id);
                        ?>
                        <button class="save-btn transition duration-300" data-resep-id="<?php echo e($resep->id); ?>">
                            <?php if($isSaved): ?>

                                <svg class="w-8 h-8 text-yellow-500" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" aria-label="Tersimpan">
                                    <path d="M7.833 2c-.507 0-.98.216-1.318.576A1.92 1.92 0 0 0 6 3.89V21a1 1 0 0 0 1.625.78L12 18.28l4.375 3.5A1 1 0 0 0 18 21V3.889c0-.481-.178-.954-.515-1.313A1.808 1.808 0 0 0 16.167 2H7.833Z"/>
                                </svg>
                            <?php else: ?>

                                <svg class="w-8 h-8 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-label="Simpan">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M17 21l-5-4-5 4V3.889a.92.92 0 0 1 .244-.629.808.808 0 0 1 .59-.26h8.333a.81.81 0 0 1 .589.26.92.92 0 0 1 .244.63V21z" />
                                </svg>
                            <?php endif; ?>
                        </button>
                    <?php endif; ?>
                </div>

                <p class="text-sm flex items-center gap-4">
                     
                    <span class="flex items-center gap-1">
                        <svg class="w-4 h-4 text-green-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                d="M12 8v4l3 3M3.223 14C4.132 18.008 7.717 21 12 21c4.97 0 9-4.03 9-9 0-4.97-4.03-9-9-9-3.73 0-6.93 2.27-8.294 5.5M7 9H3V5"/>
                        </svg>
                        <span><?php echo e($resep->waktu); ?> Menit</span>
                    </span>
                    
                     
                    <span class="flex items-center gap-1">
                        <svg class="w-4 h-4 mr-1 text-green-700 " aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                            <path fill-rule="evenodd" d="M8 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm-2 9a4 4 0 0 0-4 4v1a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-1a4 4 0 0 0-4-4H6Zm7.25-2.095c.478-.86.75-1.85.75-2.905a5.973 5.973 0 0 0-.75-2.906 4 4 0 1 1 0 5.811ZM15.466 20c.34-.588.535-1.271.535-2v-1a5.978 5.978 0 0 0-1.528-4H18a4 4 0 0 1 4 4v1a2 2 0 0 1-2 2h-4.535Z" clip-rule="evenodd"/>
                        </svg>
                        <span><?php echo e($resep->porsi); ?> Orang</span>
                    </span>

                     
                    <span class="flex items-center gap-1">
                        <?php if($resep->total_rating): ?>
                            <span class="text-yellow-500 font-semibold text-sm">
                                ★ <?php echo e(number_format($resep->total_rating, 1)); ?> 
                            </span>
                        <?php else: ?>
                            <span class="text-yellow-500 font-semibold text-sm">
                                ★ <?php echo e(number_format($resep->total_rating, 1)); ?> 
                            </span>
                        <?php endif; ?>
                    </span>
                </p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

          
        <div class="flex justify-center m-10">
            <a href="<?php echo e(route('resep.semua')); ?>" class="px-6 py-3 bg-green-600 text-white font-semibold rounded-lg shadow-lg hover:bg-green-700 transition-all duration-300">
                Lihat Semua
            </a>
        </div>

    </div>
</div>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Akhir\dapurlima\resources\views/makanan/detail.blade.php ENDPATH**/ ?>