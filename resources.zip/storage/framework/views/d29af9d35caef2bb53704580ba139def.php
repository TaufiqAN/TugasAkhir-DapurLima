

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto py-10 mt-28">
    <h2 class="text-3xl font-bold text-gray-800">Resep yang Disimpan</h2>
    
    <?php if($savedResep->isEmpty()): ?>
        <p class="text-gray-500 mt-4">Belum ada resep yang disimpan.</p>
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-6">
            <?php $__currentLoopData = $savedResep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $save): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="block group">
                    <!-- Gambar dengan link -->
                    <a href="<?php echo e(route('makanan.detail', $save->resep->id)); ?>" class="block">
                        <div class="relative overflow-hidden rounded-lg">
                            <img src="<?php echo e(asset('storage/' . $save->resep->image)); ?>" 
                                alt="<?php echo e($save->resep->nama_resep); ?>"
                                class="w-full h-52 object-cover rounded-lg brightness-75 transition-all duration-300 
                                    group-hover:brightness-100 group-hover:scale-105">
                        </div>
                    </a>
    
                    <div class="mt-4 flex justify-between items-start">
                        <!-- Nama resep dengan link -->
                        <a href="<?php echo e(route('makanan.detail', $save->resep->id)); ?>" class="text-xl font-semibold text-gray-900 group-hover:text-green-700 transition-all duration-300 min-h-[50px]">
                            <?php echo e($save->resep->nama_resep); ?>

                        </a>
    
                        <!-- Bookmark Icon -->
                        <?php if(auth()->guard()->check()): ?>
                            <?php
                                $isSaved = auth()->user()->saves->contains('resep_id', $save->resep->id);
                            ?>
                            <button class="save-btn transition duration-300" data-resep-id="<?php echo e($save->resep->id); ?>">
                                <?php if($isSaved): ?>
                                    <!-- Sudah disimpan -->
                                    <svg class="w-8 h-8 text-yellow-500" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" aria-label="Tersimpan">
                                        <path d="M7.833 2c-.507 0-.98.216-1.318.576A1.92 1.92 0 0 0 6 3.89V21a1 1 0 0 0 1.625.78L12 18.28l4.375 3.5A1 1 0 0 0 18 21V3.889c0-.481-.178-.954-.515-1.313A1.808 1.808 0 0 0 16.167 2H7.833Z"/>
                                    </svg>
                                <?php else: ?>
                                    <!-- Belum disimpan -->
                                    <svg class="w-8 h-8 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-label="Simpan">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M17 21l-5-4-5 4V3.889a.92.92 0 0 1 .244-.629.808.808 0 0 1 .59-.26h8.333a.81.81 0 0 1 .589.26.92.92 0 0 1 .244.63V21z" />
                                    </svg>
                                <?php endif; ?>
                            </button>
                        <?php endif; ?>
                    </div>
    
                    <p class="text-sm flex items-center gap-4 mt-2">
                        <!-- Ikon Waktu -->
                        <span class="flex items-center gap-1">
                            <svg class="w-4 h-4 text-green-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M12 8v4l3 3M3.223 14C4.132 18.008 7.717 21 12 21c4.97 0 9-4.03 9-9 0-4.97-4.03-9-9-9-3.73 0-6.93 2.27-8.294 5.5M7 9H3V5"/>
                            </svg>
                            <span><?php echo e($save->resep->waktu); ?> Menit</span>
                        </span>
    
                         <!-- Rating -->
                         <span class="flex items-center gap-1">
                            <?php if($save->resep->total_rating): ?>
                                <span class="text-yellow-500 font-semibold text-sm">
                                    ★ <?php echo e(number_format($save->resep->total_rating, 1)); ?> 
                                </span>
                            <?php else: ?>
                                <span class="text-yellow-500 font-semibold text-sm">
                                    ★ <?php echo e(number_format($save->resep->total_rating, 1)); ?> 
                                </span>
                            <?php endif; ?>
                        </span>
                    </p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Akhir\dapurlima\resources\views/profile/profile.blade.php ENDPATH**/ ?>