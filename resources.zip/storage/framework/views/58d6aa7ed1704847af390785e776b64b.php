


<div class="fixed inset-0 bg-gray-50 items-center flex justify-center ">
    <div class="bg-white max-w-4xl rounded-lg shadow-lg p-6">
        <h2 class="text-2xl font-bold text-gray-700 mb-4">Tambah Kategori</h2>

        <form action="<?php echo e(route('kategori.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <!-- Nama Kategori -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Nama Kategori</label>
                <input type="text" id="" name="nama_kategori" placeholder="Masukkan nama" 
                    class="w-full px-4 py-2 border rounded-lg focus:ring focus:ring-blue-300">
                <?php $__errorArgs = ['nama_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Background Warna</label>
                <input type="color" id="" name="background_color"
                    class="w-16 h-10 border rounded-lg">
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Nama Gambar</label>
                <input type="file" id="" name="image" class="w-full px-4 py-2 border rounded-lg focus:ring focus:ring-blue-300">
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Tombol -->
            <div class="flex justify-end space-x-3">
                <button type="submit" class="px-4 py-2 w-full bg-green-600 text-white rounded-lg hover:bg-green-700">
                    Buat
                </button>
            </div>
        </form>
    </div>
</div>

<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Akhir\dapurlima\resources\views/kategori/create.blade.php ENDPATH**/ ?>